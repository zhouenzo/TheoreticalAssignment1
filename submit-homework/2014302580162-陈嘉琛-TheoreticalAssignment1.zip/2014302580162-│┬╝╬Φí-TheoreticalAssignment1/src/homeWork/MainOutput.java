package homeWork;

import java.io.File;
import java.io.IOException;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

public class MainOutput {
	private static double[] sco = new double[25];  //�ɼ�
	private static double GPA;   //GPA
	private static double[] gpa= new double[25]; //ÿ��GPA
	private static double[] credit= new double[25]; //ѧ��
	private static double avesco; //��Ȩƽ����
	private static double n =0; //��ѧ��
	
	public static void main(String[] args) throws BiffException, WriteException, IOException{
		File file = new File("D:/2014302580162-�¼��-TheoreTicalAssignment1/result.xls");
		MainOutput.creatWorkbook(file);
	}
	//����GPA
		public static double getGPA(){
			GPA = 0;
			for(int i=0;i<24;i++){
				if(sco[i]>=90){
					gpa[i] = 4.0;
					GPA+=gpa[i]*credit[i];
				}if(sco[i]<90&&sco[i]>=85){
					gpa[i] = 3.7;
					GPA+=gpa[i]*credit[i];
				}if(sco[i]<85&&sco[i]>=82){
					gpa[i] = 3.3;
					GPA+=gpa[i]*credit[i];
				}if(sco[i]<82&&sco[i]>=78){
					gpa[i] = 3.0;
					GPA+=gpa[i]*credit[i];
				}if(sco[i]<78&&sco[i]>=75){
					gpa[i] = 2.7;
					GPA+=gpa[i]*credit[i];
				}if(sco[i]<75&&sco[i]>=72){
					gpa[i] = 2.3;
					GPA+=gpa[i]*credit[i];
				}if(sco[i]<72&&sco[i]>=68){
					gpa[i] = 2.0;
					GPA+=gpa[i]*credit[i];
				}if(sco[i]<68&&sco[i]>=64){
					gpa[i] = 1.5;
					GPA+=gpa[i]*credit[i];
				}if(sco[i]<64&&sco[i]>=60){
					gpa[i] = 1.0;
					GPA+=gpa[i]*credit[i];
				}else{
					gpa[i] = 0;
				}
			}
			GPA=GPA/n;
			return GPA;
	}
		//����
		public static void sort(Tab[] tab){
			for(int i=0;i<24;i++){
				for(int j=0;j<23-i;j++){
					if(sco[j]<sco[j+1]){
						
						String temp1 = tab[j].Tab1;
						tab[j].Tab1 = tab[j+1].Tab1;
						tab[j+1].Tab1 = temp1;
						
						String temp2 = tab[j ].Tab2;
						tab[j].Tab2 = tab[j+1].Tab2;
						tab[j+1].Tab2 = temp2;
						
						String temp3 = tab[j].Tab3;
						tab[j].Tab3 = tab[j+1].Tab3;
						tab[j+1].Tab3 = temp3;
						
						String temp4 = tab[j].Tab4;
						tab[j].Tab4 = tab[j+1].Tab4;
						tab[j+1].Tab4 = temp4;
						
						String temp5 = tab[j].Tab5;
						tab[j].Tab5 = tab[j+1].Tab5;
						tab[j+1].Tab5 = temp5;
						
						String temp6 = tab[j].Tab6;
						tab[j].Tab6 = tab[j+1].Tab6;
						tab[j+1].Tab6 = temp6;
						
						String temp7 = tab[j].Tab7;
						tab[j].Tab7 = tab[j+1].Tab7;
						tab[j+1].Tab7 = temp7;
						
						String temp8 = tab[j].Tab8;
						tab[j].Tab8 = tab[j+1].Tab8;
						tab[j+1].Tab8 = temp8;
						
						String temp9 = tab[j].Tab9;
						tab[j].Tab9 = tab[j+1].Tab9;
						tab[j+1].Tab9 = temp9;
						
						String temp10 = tab[j].Tab10;
						tab[j].Tab10 = tab[j+1].Tab10;
						tab[j+1].Tab10 = temp10;
						
						double temp =sco[j];
						sco[j] = sco[j+1];
						sco[j+1] = temp;
						
					}
				}
			}
		}
	//��ȡ����
	public static void creatWorkbook(File input) throws BiffException, IOException, WriteException{
		Workbook wb = Workbook.getWorkbook(input);
		Sheet st = wb.getSheet(0);
		Tab [] tab = new Tab[25];
		
		//��ȡÿ��CELL������һ�зֿ���ȡ
		
		for(int i=1;i<25;i++){
			sco[i-1] = 0;
			credit[i-1] = 0;
			tab[i-1]=new Tab();
			for(int j=0;j<10;j++){
				Cell cell = st.getCell(j,i);
				//��ÿ��cell������ת����STRING
				String cellString = cell.getContents();
				//��ȡÿ��CELL
				switch(j){
				case 0:
					tab[i-1].Tab1 = cellString;
					break;
				case 1:
					tab[i-1].Tab2 = cellString;
					break;
				case 2:
					tab[i-1].Tab3 = cellString;
					break;
				case 3:
					tab[i-1].Tab4 = cellString;
					break;
				case 4:
					tab[i-1].Tab5 = cellString;
					break;
				case 5:
					tab[i-1].Tab6 = cellString;
					break;
				case 6:
					tab[i-1].Tab7 = cellString;
					break;
				case 7:
					tab[i-1].Tab8 = cellString;
					break;
				case 8:
					tab[i-1].Tab9 = cellString;
					break;
				case 9:
					tab[i-1].Tab10 = cellString;
					break;
				}
			
				//��ȡѧ��
				if(j==3){
					credit[i-1] = Double.parseDouble(tab[i-1].Tab4);
				}
				//��ȡ�ɼ�
				if(j==9){
					sco[i-1] = Double.parseDouble(tab[i-1].Tab10);
				}
			}
			
			avesco+=sco[i-1]*credit[i-1];
			n+=credit[i-1];
		}
		avesco/=n;
		//����GPA
		GPA = getGPA();
		sort(tab);
			//����
			
			
			
		
		//���
		File file = new File("afterresult.xls");
		WritableWorkbook wwb = Workbook.createWorkbook(file, wb);
		WritableSheet wst = wwb.createSheet("Sheet1",0);
		//���ӱ�ǩ
		Label label00 = new Label(0,0,"��ͷ��");
		Label label01 = new Label(1,0,"�γ�����");
		Label label02 = new Label(2,0,"�γ�����");
		Label label03 = new Label(3,0,"ѧ��");
		Label label04 = new Label(4,0,"�γ̽�ʦ");
		Label label05= new Label(5,0,"�ڿ�ѧԺ");
		Label label06= new Label(6,0,"ѧϰ����");
		Label label07= new Label(7,0,"ѧ��");
		Label label08= new Label(8,0,"ѧ��");
		Label label09= new Label(9,0,"����");
		wst.addCell(label00);
		wst.addCell(label01);
		wst.addCell(label02);
		wst.addCell(label03);
		wst.addCell(label04);
		wst.addCell(label05);
		wst.addCell(label06);
		wst.addCell(label07);
		wst.addCell(label08);
		wst.addCell(label09);
		//����
		Tab[] tab2 = new Tab[24];
		
		
		
		//ѭ������ÿ����Ԫ
		for(int i=1;i<25;i++){
			Label label1 = new Label(0,i,tab[i-1].Tab1);
			Label label2 = new Label(1,i,tab[i-1].Tab2);
			Label label3 = new Label(2,i,tab[i-1].Tab3);
			Label label4 = new Label(3,i,tab[i-1].Tab4);
			Label label5 = new Label(4,i,tab[i-1].Tab5);
			Label label6 = new Label(5,i,tab[i-1].Tab6);
			Label label7 = new Label(6,i,tab[i-1].Tab7);
			Label label8 = new Label(7,i,tab[i-1].Tab8);
			Label label9 = new Label(8,i,tab[i-1].Tab9);
			Label label10 = new Label(9,i,tab[i-1].Tab10);
			wst.addCell(label1);
			wst.addCell(label2);
			wst.addCell(label3);
			wst.addCell(label4);
			wst.addCell(label5);
			wst.addCell(label6);
			wst.addCell(label7);
			wst.addCell(label8);
			wst.addCell(label9);
			wst.addCell(label10);
		}
		
		
		
		
		
		
		Label label011 = new Label(10,0,"GPA");
		Label label012 = new Label(11,0,"��Ȩƽ����");
		Label label111 = new Label(10,1,Double.toString(GPA));
		Label label112= new Label(11,1,Double.toString(avesco));
		wst.addCell(label011);
		wst.addCell(label012);
		wst.addCell(label111);
		wst.addCell(label112);
		
		
		
		
		
		
		
		
		wwb.write();
		wwb.close();
		wb.close();
		
	}
	
	

	
	
	
}
