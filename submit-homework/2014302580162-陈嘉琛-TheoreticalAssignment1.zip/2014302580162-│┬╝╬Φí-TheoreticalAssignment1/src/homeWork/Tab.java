package homeWork;
/**
 * ��ͷ
 * @author Aron
 *
 */
public class Tab {
	String Tab1;
	String Tab2;
	String Tab3;
	String Tab4;
	String Tab5;
	String Tab6;
	String Tab7;
	String Tab8;
	String Tab9;
	String Tab10;
}
